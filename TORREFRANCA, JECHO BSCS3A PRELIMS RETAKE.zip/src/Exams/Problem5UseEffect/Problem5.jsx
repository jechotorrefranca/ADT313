import { useEffect, useRef, useState } from 'react';
import Loading from './Problem5Components/Loading';
export default function Problem5() {
  const [isLoading, setIsLoading] = useState(true);
  const [isTyping, setIsTyping] = useState(true);
  const [value, setValue] = useState();

  useEffect(() => {
    const delay = setTimeout(() => {
      setIsLoading(false);
    }, 3000);
  })

  function handleChange(e) {
    setValue(e.target.value);
  }
  
  useEffect(() => {
    setIsTyping(true);

    if(isTyping) {
      setTimeout(() => {
        setIsTyping(false);
      }, 1000);

    }

  }, [value])

  return (
    <>
      {isLoading ? (
        <Loading />
      ) : (
        <>
          <div style={{ display: 'block' }}>
            Input: <input type='text' value={value} onChange={handleChange}/>
            <p>{isTyping ? "User is Typing" : "User is idle..."}</p>
          </div>
        </>
      )}
    </>
  );
}
