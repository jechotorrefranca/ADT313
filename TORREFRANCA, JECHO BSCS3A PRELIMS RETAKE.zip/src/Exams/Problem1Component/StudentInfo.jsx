function StudentInfo({ name, cAndS }) {

    return (
        <>
            <div>{name}</div>
            <div>{cAndS}</div>
        </>
    )

}

export default StudentInfo;