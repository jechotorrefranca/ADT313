import { useState } from "react";

function Problem2() {

  const [isHidden, setisHidden] = useState(true);

  const handleShow = () => {
    setisHidden(!isHidden);
  }

  const user = {
    name: 'Hedy Lamarr',
    imageUrl: 'https://i.imgur.com/yXOvdOSs.jpg',
    imageSize: 90,
  };

  function Profile() {
    return (
      <>
        <h1>{user.name}</h1>
        <img
          className='avatar'
          src={user.imageUrl}
          alt={'Photo of ' + user.name}
          style={{
            width: user.imageSize,
            height: user.imageSize,
          }}
        />
      </>
    );
  }

  function InitialContent() {
    return <h1>User profile is hidden.</h1>;
  }

  const SecondaryContent = ({children}) => {
    return (
      <div>
        <h1>User profile is not hidden.</h1>
        {children}
      </div>
    )
  }



  return (
    <>
      <div>
        {isHidden ? <InitialContent /> : <SecondaryContent><Profile/></SecondaryContent>}
        
        <button type='button' onClick={handleShow}>{isHidden ? "Show Profile" : "Hide Profile"}</button>
      </div>
    </>
  );
}

export default Problem2;
