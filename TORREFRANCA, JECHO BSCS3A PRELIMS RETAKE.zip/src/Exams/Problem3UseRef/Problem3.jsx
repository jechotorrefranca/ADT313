import { useEffect, useRef, useState } from "react";

function Problem3() {
  
  const input1 = useRef();
  const input2 = useRef();
  const input3 = useRef();
  const input4 = useRef();
  const input5 = useRef();
  const input6 = useRef();
  const input7 = useRef();
  const input8 = useRef();
  const input9 = useRef();
  const input10 = useRef();

  const checkEmpty = () => {
    if (input1.current.value === "") {
      input1.current.focus();
    } else if (input2.current.value === "") {
      input2.current.focus();
    } else if (input3.current.value === "") {
      input3.current.focus();
    } else if (input4.current.value === "") {
      input4.current.focus();
    } else if (input5.current.value === "") {
      input5.current.focus();
    } else if (input6.current.value === "") {
      input6.current.focus();
    } else if (input7.current.value === "") {
      input7.current.focus();
    } else if (input8.current.value === "") {
      input8.current.focus();
    } else if (input9.current.value === "") {
      input9.current.focus();
    } else if (input10.current.value === "") {
      input10.current.focus();
    }
  };

  return (
    <>
      <div style={{ display: "block" }}>
        Input 1: <input type="text" ref={input1}/>
      </div>
      <div style={{ display: "block" }}>
        Input 2: <input type="text" ref={input2}/>
      </div>
      <div style={{ display: "block" }}>
        Input 3: <input type="text" ref={input3}/>
      </div>
      <div style={{ display: "block" }}>
        Input 4: <input type="text" ref={input4}/>
      </div>
      <div style={{ display: "block" }}>
        Input 5: <input type="text" ref={input5}/>
      </div>
      <div style={{ display: "block" }}>
        Input 6: <input type="text" ref={input6}/>
      </div>
      <div style={{ display: "block" }}>
        Input 7: <input type="text" ref={input7}/>
      </div>
      <div style={{ display: "block" }}>
        Input 8: <input type="text" ref={input8}/>
      </div>
      <div style={{ display: "block" }}>
        Input 9: <input type="text" ref={input9}/>
      </div>
      <div style={{ display: "block" }}>
        Input 10: <input type="text" ref={input10}/>
      </div>
      <button type="button" onClick={checkEmpty}>I'm a button</button>
    </>
  );
}

export default Problem3;
