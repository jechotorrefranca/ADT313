import { useState } from 'react';

export default function Problem4() {

  const [name, setName] = useState();
  const [yr, setYr] = useState();
  const [course, setCourse] = useState();

  const [data, setData] = useState({
    name,
    yr,
    course

  });

  function handleChange(e) {
    data({...data,
      name: e.target.value
    })
  }

  const updateState = (e) => {
    setData(prev => ({...prev, name: e}));
  };
 

  return (
    <>
      <div style={{ display: 'block' }}>
        Name: <input type='text' onChange={(e) =>
          setData({...data, name: e.target.value})
        }/>
      </div>


      <div style={{ display: 'block' }}>
        <p>Yearlevel:</p>
        <input 
          type='radio' 
          id='firstYear' 
          name='yearlevel' 
          value='Fist Year'
          onClick={(e) =>
            setData({...data, yr: e.target.value})}/>
          <label for='firstYear'>Fist Year</label>
        <br></br>
        <input
          type='radio'
          id='secondYear'
          name='yearlevel'
          value='Second Year'
          onClick={(e) =>
            setData({...data, yr: e.target.value})}
        />
          <label for='secondYear'>Second Year</label>
        <br></br>
        <input
          type='radio'
          id='thirdYear'
          name='yearlevel'
          value='Third Year'
          onClick={(e) =>
            setData({...data, yr: e.target.value})}
        />
          <label for='thirdYear'>Third Year</label>
        <br></br>
        <input
          type='radio'
          id='fourthYear'
          name='yearlevel'
          value='Fourth Year'
        />
          <label for='fourthYear'>Fourth Year</label>
        <br></br>
        <input
          type='radio'
          id='fifthYear'
          name='yearlevel'
          value='Fourth Year'
          onClick={(e) =>
            setData({...data, yr: e.target.value})}
        />
          <label for='fifthYear'>Fifth Year</label>
        <br></br>
        <input type='radio' id='irregular' name='yearlevel' value='Irregular' 
        onClick={(e) =>
          setData({...data, yr: e.target.value})}/>
          <label for='irregular'>Irregular</label>
        <br></br>
      </div>
      <div style={{ display: 'block' }}>
        Course:
        <select onChange={(e) =>
            setData({...data, course: e.target.value})}>
          <option value='BSCS'>BSCS</option>
          <option value='BSIT'>BSIT</option>
          <option value='BSCpE'>BSCpE</option>
          <option value='ACT'>ACT</option>
        </select>
      </div>

      { JSON.stringify(data) }
    </>
  );
}
